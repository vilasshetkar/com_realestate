<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>



<div class="featured_project">
<ul>

		 <?php foreach($hello as $i => $item): ?>
<?php 
$link = JRoute::_( "index.php?option=com_realestate&view=project&layout=SingleProject&id=".$item['id'] ); 
$ViewAll= JRoute::_( "index.php?option=com_realestate&view=project"); 
$email = JRoute::_( "index.php?option=com_realestate&view=Default&layout=Email&id=".$item['id']  );
$refer = JRoute::_( "index.php?option=com_realestate&view=Default&layout=ReferFriend&id=".$item['id']  );
?>
<li>
          <div class="project_box">
            <table height="76" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="146" scope="col"><h1>
	              <a class="fancybox" href="<?php echo $link ; ?>">
					<?php echo $item['title'];?>
        	      </a>
				</h1></td>
              </tr>
              <tr>
                <td align="center" scope="col">
                  <a class="fancybox" href="<?php echo $link ; ?>">
                  <img src="http://jaidevlandmarks.com/admin/upload/uploaded-files/no_photo_icon.jpg" />
                  </a>
                </td>
              </tr>
            </table>
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="77" align="left" valign="top" scope="col"><strong>Location:</strong></td>
                <td width="147" align="left" valign="top" scope="col"><?php echo $item['location'];?></td>
              </tr>
              <tr>
                <td align="left" valign="top"><strong>Type:</strong></td>
                <td align="left" valign="top"><?php echo $item['type'];?></td>
              </tr>
              <tr>
                <td colspan="2" align="left" valign="top"><a href="<?php echo $link ; ?>">More Details</a> <strong>›</strong></td>
              </tr>
            </table>
          </div>
</li>
<?php endforeach; ?>
<div class="clear"></div>
</ul>
<div class="ViewAll">
<a href="<?php echo $ViewAll ; ?>" title="Click Here to View All Projects">View All Projects</a>
</div>
</div>
