<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>

<table>
<tbody>
		 <?php foreach($hello as $i => $item): ?>

<tr class="row<?php echo $i % 2; ?>">
<td>
<?php 
$link = JRoute::_( "index.php?option=com_realestate&view=Default&layout=SingleProperty&id=".$item['id'] ); 
$ViewAll = JRoute::_( "index.php?option=com_realestate&view=Default"); 
$email = JRoute::_( "index.php?option=com_realestate&view=Default&layout=Email&id=".$item['id']  );
$refer = JRoute::_( "index.php?option=com_realestate&view=Default&layout=ReferFriend&id=".$item['id']  );
?>
<div class="featured_property">
	<div class="property_img">
              <a class="fancybox" href="?r_prop=<?php echo $item['id'];?>">
              <img src="/no_photo_icon.jpg" />
              </a>              
	</div>
        <div class="proj_detail">
        <h2><a href="<?php echo $link ; ?>"><?php echo $item['title'];?></a></h2>
        <table width="100%" border="1" cellpadding="5" cellspacing="0">
          <tr valign="top"></tr>
          <tr valign="top">
            <th width="19%">Property Type</th>
            <td width="81%"><?php echo $item['type'];?> &rArr;<strong> For <?php echo $item['property_for']?></strong></td>
          </tr>
          <tr valign="top">
            <th>Built Up</th>
            <td><?php echo $item['buildup_area'].' '.$item['build_unit'];?>, <?php echo $item['bedrooms'];?> Bedroom(s), <?php echo $item['bathrooms'];?> Bathroom(s)</td>
          </tr>
          <tr valign="top">
            <th>Location</th>
            <td><?php echo $item['address'];?></td>
          </tr>
          <tr valign="top">
            <th>Price</th>
            <td><?php if($item['price']==0){echo "Call for Price!";}else {echo $item['price'];}?></td>
          </tr>
          <tr valign="top">
            <th> </th>
            <td><a href="<?php echo $link; ?>">More Detail</a> | <a class="sendmail" href="<?php echo $email; ?>">Send Email</a> | <a href="<?php echo $refer; ?>">Refer Friend</a></td>
          </tr>
        </table>
        </div>
        <div class="clear"></div>
    </div>
    </td>
</tr>
<?php endforeach; ?>
<tr>
<td>
<div class="ViewAll">
<a href="<?php echo $ViewAll ; ?>" title="Click Here to View All Properties">View All Properties</a>
</div>
</td>
</tr>
</tbody>
</table>
